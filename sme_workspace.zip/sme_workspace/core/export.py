# core/export.py
from docx import Document

def export_docx(text: str, path: str) -> str:
    doc = Document()
    doc.add_heading("ЗАКЛЮЧЕНИЕ ЭКСПЕРТА (черновик, требует подписи)", level=1)
    for line in text.splitlines():
        if line.startswith("==="):
            doc.add_heading(line.strip("= "), level=2)
        else:
            doc.add_paragraph(line)
    doc.save(path)
    return path
