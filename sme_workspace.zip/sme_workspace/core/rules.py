# core/rules.py
import json
from pathlib import Path

def _load_known_dx() -> dict:
    p = Path(__file__).resolve().parent.parent / "config" / "abbreviations.json"
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
        return {k: v for k, v in data.items() if not k.startswith("_")}
    except Exception:
        return {"АБС": "абсцесс / абстинентный синдром (уточнить)",
                "ОИМ": "острый инфаркт миокарда"}

KNOWN_DX = _load_known_dx()

def build_diagnosis(merged: dict, case: dict) -> dict:
    tox = merged.get("labs.toxicology", (None, None, None))[1] or {}
    dx = {"main": None, "complication": None, "comorbid": None, "manipulations": None,
          "blocked": [], "warnings": []}

    if isinstance(tox, dict) and tox.get("positive") and tox.get("drug") == "метадон":
        drug = tox.get("drug") or "[УТОЧНИТЬ ВЕЩЕСТВО]"
        blood = tox.get("blood")
        urine = tox.get("urine")
        blood_s = f"{blood} мг/л" if blood is not None else "н/д"
        urine_s = f"{urine} мг/л" if urine is not None else "н/д"
        if blood is None or urine is None:
            dx["warnings"].append("Концентрации метадона не извлечены — сверьте с протоколом СХО.")
        dx["main"] = (f"Острое отравление метадоном: метадон "
                      f"(в крови {blood_s}, в моче {urine_s}), "
                      f"основной метаболит EDDP.")
        dx["complication"] = "-"
    else:
        dx["main"] = merged.get("dx.main", (None, None, None))[1]

    dx["comorbid"] = merged.get("dx.comorbid", (None, None, None))[1]
    dx["manipulations"] = merged.get("dx.manipulations", (None, None, None))[1]

    # Стоп-фактор: неизвестная аббревиатура
    prelim = (case.get("meta.preliminary") or "").upper()
    if prelim and prelim not in KNOWN_DX:
        dx["blocked"].append(f"Неизвестный предварительный диагноз «{prelim}» — расшифруйте.")
    return dx

def build_conclusions(merged: dict, case: dict) -> list[str]:
    out = []
    n = 1
    tox = merged.get("labs.toxicology", (None, None, None))[1] or {}
    if isinstance(tox, dict) and tox.get("positive"):
        drug = tox.get("drug") or "[УТОЧНИТЬ ВЕЩЕСТВО]"
        out.append(f"{n}. Смерть наступила от острого отравления {drug}.")
    elif merged.get("dx.main", (None, None, None))[1]:
        out.append(f"{n}. Смерть наступила от: {merged['dx.main'][1]}")
    else:
        out.append(f"{n}. [НЕ СОБРАНО — нет основного диагноза]")

    if isinstance(tox, dict):
        if tox.get("ethanol") is False:
            out.append(f"{n + 1}. В биологических жидкостях этиловый спирт не обнаружен.")
        elif tox.get("ethanol") is None:
            out.append(f"{n + 1}. Спирты не исследовались — уточните по протоколу СХО.")
    return out
