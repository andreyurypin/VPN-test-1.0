# core/db.py
import sqlite3, json, hashlib, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

def _default_db_path() -> Path:
    try:
        cfg = json.loads((ROOT / "config" / "settings.json").read_text(encoding="utf-8"))
        p = ROOT / cfg.get("db_path", "data/sme.db")
    except Exception:
        p = ROOT / "data" / "sme.db"
    p.parent.mkdir(parents=True, exist_ok=True)
    return p

DB_PATH = _default_db_path()

SCHEMA = """
CREATE TABLE IF NOT EXISTS documents (
    id INTEGER PRIMARY KEY,
    number TEXT,
    date TEXT,
    expert TEXT,
    source TEXT,               -- archive | live | import
    status TEXT,               -- draft | signed | approved_as_base | deprecated
    raw_text TEXT,
    fingerprint TEXT UNIQUE,
    created_at TEXT,
    updated_at TEXT
);

CREATE TABLE IF NOT EXISTS block_values (
    id INTEGER PRIMARY KEY,
    document_id INTEGER REFERENCES documents(id) ON DELETE CASCADE,
    block_id TEXT NOT NULL,
    value_json TEXT,
    rendered TEXT,
    extracted_by TEXT,         -- parser_v1 | llm | expert
    confidence REAL,
    status TEXT,               -- needs_review | approved | rejected | deprecated
    tags_json TEXT,
    version INTEGER DEFAULT 1,
    superseded_by_id INTEGER REFERENCES block_values(id),
    created_at TEXT,
    confirmed_by TEXT,
    confirmed_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_bv_block ON block_values(block_id, status);
CREATE INDEX IF NOT EXISTS idx_bv_doc ON block_values(document_id);

CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
);
"""

class DB:
    def __init__(self, path=None):
        self.path = Path(path) if path else DB_PATH
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(str(self.path))
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys = ON")
        self.conn.executescript(SCHEMA)
        self.conn.commit()

    # ---------- documents ----------
    def has_fingerprint(self, fp: str) -> bool:
        row = self.conn.execute(
            "SELECT 1 FROM documents WHERE fingerprint = ?", (fp,)
        ).fetchone()
        return row is not None

    def insert_document(self, number, date, expert, raw_text, fingerprint,
                        source="archive", status="draft") -> int:
        now = datetime.datetime.now().isoformat(timespec="seconds")
        cur = self.conn.execute("""
            INSERT INTO documents
                (number, date, expert, source, status, raw_text, fingerprint,
                 created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (number, date, expert, source, status, raw_text, fingerprint, now, now))
        self.conn.commit()
        return cur.lastrowid

    def update_document_status(self, doc_id: int, status: str):
        now = datetime.datetime.now().isoformat(timespec="seconds")
        self.conn.execute(
            "UPDATE documents SET status = ?, updated_at = ? WHERE id = ?",
            (status, now, doc_id)
        )
        self.conn.commit()

    def list_documents(self, status=None):
        sql = "SELECT * FROM documents"
        args = ()
        if status:
            sql += " WHERE status = ?"
            args = (status,)
        sql += " ORDER BY date DESC, id DESC"
        return [dict(r) for r in self.conn.execute(sql, args).fetchall()]

    # ---------- block_values ----------
    def insert_block_value(self, document_id, block_id, value, rendered=None,
                           extracted_by="parser_v1", confidence=1.0,
                           status="needs_review", tags=None) -> int:
        now = datetime.datetime.now().isoformat(timespec="seconds")
        cur = self.conn.execute("""
            INSERT INTO block_values
                (document_id, block_id, value_json, rendered, extracted_by,
                 confidence, status, tags_json, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (document_id, block_id, json.dumps(value, ensure_ascii=False),
              rendered, extracted_by, confidence, status,
              json.dumps(tags or {}, ensure_ascii=False), now))
        self.conn.commit()
        return cur.lastrowid

    def get_block_value(self, bv_id: int):
        row = self.conn.execute(
            "SELECT * FROM block_values WHERE id = ?", (bv_id,)
        ).fetchone()
        return dict(row) if row else None

    def approve_block(self, bv_id: int, expert: str):
        now = datetime.datetime.now().isoformat(timespec="seconds")
        self.conn.execute("""
            UPDATE block_values
               SET status = 'approved', confirmed_by = ?, confirmed_at = ?
             WHERE id = ?
        """, (expert, now, bv_id))
        self.conn.commit()

    def reject_block(self, bv_id: int, expert: str):
        now = datetime.datetime.now().isoformat(timespec="seconds")
        self.conn.execute("""
            UPDATE block_values
               SET status = 'rejected', confirmed_by = ?, confirmed_at = ?
             WHERE id = ?
        """, (expert, now, bv_id))
        self.conn.commit()

    def set_block_status(self, bv_id: int, status: str):
        """Отзыв одобрения или пометка deprecated из вкладки «Библиотека»."""
        assert status in ("needs_review", "approved", "rejected", "deprecated")
        self.conn.execute(
            "UPDATE block_values SET status = ? WHERE id = ?", (status, bv_id)
        )
        self.conn.commit()

    def supersede_block(self, document_id: int, block_id: str, new_bv_id: int):
        """Депрекирует прежнюю approved-версию блока из того же документа."""
        row = self.conn.execute("""
            SELECT id FROM block_values
             WHERE document_id = ? AND block_id = ?
               AND status = 'approved' AND id != ?
        """, (document_id, block_id, new_bv_id)).fetchone()
        if row:
            self.conn.execute("""
                UPDATE block_values
                   SET status = 'deprecated', superseded_by_id = ?
                 WHERE id = ?
            """, (new_bv_id, row["id"]))
            self.conn.commit()
            return row["id"]
        return None

    def candidates(self, block_id: str):
        rows = self.conn.execute("""
            SELECT bv.*, d.number AS doc_number, d.date AS doc_date,
                   d.expert AS doc_expert, d.id AS doc_id
              FROM block_values bv
              JOIN documents d ON d.id = bv.document_id
             WHERE bv.block_id = ?
               AND bv.status = 'approved'
               AND d.status IN ('signed','approved_as_base')
             ORDER BY d.date DESC, bv.confidence DESC
        """, (block_id,)).fetchall()
        return [dict(r) for r in rows]

    def block_ids_with_approved(self):
        rows = self.conn.execute("""
            SELECT DISTINCT block_id FROM block_values
             WHERE status = 'approved'
        """).fetchall()
        return [r["block_id"] for r in rows]

    def list_approved_blocks(self, block_id=None):
        """Для вкладки «Библиотека»: все approved-блоки с данными документа."""
        sql, args = """
            SELECT bv.id, bv.block_id, bv.value_json, bv.rendered, bv.confidence,
                   bv.confirmed_by, bv.confirmed_at, bv.version,
                   d.number AS doc_number, d.date AS doc_date, d.id AS doc_id
              FROM block_values bv
              JOIN documents d ON d.id = bv.document_id
             WHERE bv.status = 'approved'
        """, []
        if block_id:
            sql += " AND bv.block_id = ?"
            args.append(block_id)
        sql += " ORDER BY bv.block_id, d.date DESC, bv.id DESC"
        return [dict(r) for r in self.conn.execute(sql, args).fetchall()]

    # ---------- settings ----------
    def get_setting(self, key, default=None):
        row = self.conn.execute(
            "SELECT value FROM settings WHERE key = ?", (key,)
        ).fetchone()
        return row["value"] if row else default

    def set_setting(self, key, value):
        self.conn.execute("""
            INSERT INTO settings(key, value) VALUES(?, ?)
            ON CONFLICT(key) DO UPDATE SET value = excluded.value
        """, (key, value))
        self.conn.commit()

    def close(self):
        self.conn.close()
