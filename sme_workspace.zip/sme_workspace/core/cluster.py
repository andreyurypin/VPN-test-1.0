# core/cluster.py
"""Кластеризация одинаковых фрагментов из разных документов."""
import json

def _key(bv: dict):
    return (bv.get("block_id"), bv.get("value_json"))

def find_duplicate_groups(db) -> list[list[dict]]:
    rows = db.conn.execute("""
        SELECT id, block_id, value_json, confidence, document_id
          FROM block_values WHERE status = 'approved'
    """).fetchall()
    groups = {}
    for r in rows:
        d = dict(r)
        groups.setdefault(_key(d), []).append(d)
    return [v for v in groups.values() if len(v) > 1]

def prune_duplicates(db, dry_run: bool = True):
    """Оставляет в каждой группе эталон (максимальный confidence),
    остальные депрекирует со ссылкой на эталон. Возвращает [(old_id, ref_id)]."""
    changed = []
    for group in find_duplicate_groups(db):
        ref = max(group, key=lambda r: (r["confidence"] or 0))
        for r in group:
            if r["id"] != ref["id"]:
                changed.append((r["id"], ref["id"]))
                if not dry_run:
                    db.conn.execute("""
                        UPDATE block_values
                           SET status = 'deprecated', superseded_by_id = ?
                         WHERE id = ?
                    """, (ref["id"], r["id"]))
    if not dry_run:
        db.conn.commit()
    return changed
