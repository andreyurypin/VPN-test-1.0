# core/scoring.py

def extract_features(case: dict) -> dict:
    """Фичи кейса. None = признак неизвестен (не путать с False!)."""
    f = {"sex": None, "length": None, "weight": None,
         "has_injuries": None, "has_scars": None,
         "toxicology_positive": None, "drug": None,
         "vessels_hard": None, "heart_mass": None}
    b = case.get("ext.body")
    if isinstance(b, dict):
        f["sex"] = b.get("sex")
        f["length"] = b.get("length")
        f["weight"] = b.get("weight")
    if "ext.injuries" in case:
        f["has_injuries"] = bool(case["ext.injuries"])
    if "ext.scars" in case:
        f["has_scars"] = bool(case["ext.scars"])
    tox = case.get("labs.toxicology") or {}
    if isinstance(tox, dict) and "positive" in tox:
        f["toxicology_positive"] = tox.get("positive")
        f["drug"] = tox.get("drug")
    v = case.get("int.vessels")
    if isinstance(v, str):
        f["vessels_hard"] = "хруст" in v.lower()
    h = case.get("int.heart")
    if isinstance(h, dict):
        f["heart_mass"] = h.get("mass")
    return f

def score(case_f: dict, base_f: dict) -> tuple[int, list[str]]:
    """Совпадение засчитывается, только когда ОБА значения известны."""
    s, why = 0, []
    if case_f["sex"] and case_f["sex"] == base_f["sex"]:
        s += 10; why.append("+10 пол")
    if case_f["length"] is not None and base_f["length"] is not None:
        d = abs(case_f["length"] - base_f["length"])
        if d <= 3: s += 5; why.append("+5 длина ±3")
        elif d <= 7: s += 2; why.append("+2 длина ±7")
    if case_f["weight"] is not None and base_f["weight"] is not None:
        if abs(case_f["weight"] - base_f["weight"]) <= 5:
            s += 3; why.append("+3 вес ±5")
    if case_f["has_injuries"] is not None and case_f["has_injuries"] == base_f["has_injuries"]:
        s += 10; why.append("+10 совпало наличие повреждений")
    if case_f["has_scars"] is not None and case_f["has_scars"] == base_f["has_scars"]:
        s += 3; why.append("+3 совпало наличие рубцов")
    if case_f["toxicology_positive"] is not None and \
       case_f["toxicology_positive"] == base_f["toxicology_positive"]:
        s += 10; why.append("+10 совпала токсикология")
    if case_f["drug"] and case_f["drug"] == base_f["drug"]:
        s += 8; why.append("+8 совпал препарат")
    if case_f["vessels_hard"] is not None and \
       case_f["vessels_hard"] == base_f["vessels_hard"]:
        s += 4; why.append("+4 совпал характер сосудов")
    if case_f["heart_mass"] is not None and base_f["heart_mass"] is not None:
        if abs(case_f["heart_mass"] - base_f["heart_mass"]) <= 50:
            s += 3; why.append("+3 масса сердца ±50")
    return s, why

def rank_bases(case: dict, bases: dict) -> list[tuple[str, int, list[str]]]:
    cf = extract_features(case)
    out = []
    for name, b in bases.items():
        sc, why = score(cf, extract_features(b))
        out.append((name, sc, why))
    return sorted(out, key=lambda x: -x[1])
