# core/anonymize.py
import re

PII_PATTERNS = [
    re.compile(r"[А-ЯЁ][а-яё]+\s+[А-ЯЁ]\.\s*[А-ЯЁ]\."),            # Иванов И.И.
    re.compile(r"[А-ЯЁ][а-яё]+\s+[А-ЯЁ][а-яё]+\s+[А-ЯЁ][а-яё]+"),  # Иванов Иван Иванович
    re.compile(r"(ул\.|улица|пр-?кт|проспект|пер\.|переулок)\s*[^,\n;]+", re.I),
    re.compile(r"(паспорт|серия|кем выдан)[^,\n;]+", re.I),
    re.compile(r"\b\d{2}\.\d{2}\.\d{4,6}\b"),                       # даты 00.00.0000 / 000000
]

REPL = "[ДАННЫЕ УДАЛЕНЫ]"

def anonymize(text: str) -> str:
    for pat in PII_PATTERNS:
        text = pat.sub(REPL, text)
    return text
