# core/render.py
from jinja2 import Environment
from core.blocks import BY_ID
from core.merge import State, apply_confirmations

env = Environment(trim_blocks=True, lstrip_blocks=True)

def render_block(bid: str, value) -> str:
    b = BY_ID[bid]
    return env.from_string(b.template).render(v=value).strip()

TAGS = {
    "SET": "[ИЗМ]", "CONFIRMED": "[OK]", "INHERITED": "[?]",
    "CONFLICT": "[!]", "UNSET": "[-]", "DELETED": "[X]",
}

def render_report(merged: dict, confirmed: set) -> str:
    merged = apply_confirmations(merged, confirmed)
    parts, current = [], None
    for bid, (state, val, src) in merged.items():
        if state in (State.UNSET, State.DELETED) or val is None:
            continue
        b = BY_ID[bid]
        if b.section != current:
            parts.append(f"\n=== {b.section.upper()} ===\n")
            current = b.section
        tag = TAGS[state.value.upper()]
        parts.append(f"{tag} {render_block(bid, val)}")
    return "\n".join(parts)
