# core/blocks.py
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path

class BType(Enum):
    BOILER = "boiler"          # наследуется свободно
    CASE = "case"              # наследуется только с подтверждением
    CALC = "calc"              # вычисляется
    EXPERT = "expert"          # только эксперт, никогда не наследуется слепо

TEMPLATE_DIR = Path(__file__).resolve().parent.parent / "config" / "templates"

def _load_templates() -> dict:
    """Парсит config/templates/*.j2: блоки разделены заголовками '### block_id'."""
    tpl = {}
    if TEMPLATE_DIR.exists():
        for f in sorted(TEMPLATE_DIR.glob("*.j2")):
            cur, buf = None, []
            for line in f.read_text(encoding="utf-8").splitlines():
                if line.startswith("### "):
                    if cur:
                        tpl[cur] = "\n".join(buf).strip()
                    cur, buf = line[4:].strip(), []
                elif cur is not None:
                    buf.append(line)
            if cur:
                tpl[cur] = "\n".join(buf).strip()
    return tpl

_TPL = _load_templates()

@dataclass
class Block:
    id: str
    section: str
    title: str
    btype: BType
    template: str = ""
    features: list = field(default_factory=list)

# (block_id, section, title, btype, fallback_template — используется, если в config/templates не найден)
_SPECS = [
    # --- НАРУЖНОЕ ---
    ("ext.clothing", "Наружное", "Одежда", BType.BOILER,
     "Труп доставлен в {{ v }}."),
    ("ext.body", "Наружное", "Пол/рост/вес", BType.BOILER,
     "Труп {{ v.sex }} пола, длиной тела {{ v.length }} см, массой {{ v.weight }} кг."),
    ("ext.rigor", "Наружное", "Трупное окоченение", BType.BOILER,
     "Трупное окоченение {{ v }}."),
    ("ext.spots", "Наружное", "Трупные пятна", BType.CASE,
     "Трупные пятна {{ v.color }}, располагаются {{ v.location }}. "
     "При надавливании {{ v.reaction }}{% if v.pale_time %}, "
     "бледнеют через {{ v.pale_time }} минут{% endif %}."),
    ("ext.hair", "Наружное", "Волосы", BType.BOILER,
     "Волосы на голове {{ v.color }}, длиной до {{ v.length }} см."),
    ("ext.eyes", "Наружное", "Глаза", BType.BOILER,
     "Радужные оболочки {{ v.iris }}, зрачки округлой формы по {{ v.pupil }} см."),
    ("ext.teeth", "Наружное", "Зубы", BType.CASE,
     "Зубы: {{ v }}."),
    ("ext.injuries", "Наружное", "Повреждения", BType.CASE,
     "{% if v %}{% for i in v %}• {{ i }}\n{% endfor %}"
     "{% else %}Повреждений при наружном исследовании не обнаружено.{% endif %}"),
    ("ext.scars", "Наружное", "Рубцы", BType.CASE,
     "{% if v %}Рубцы: {{ v }}.{% else %}Рубцов не обнаружено.{% endif %}"),
    # --- ВНУТРЕННЕЕ ---
    ("int.heart", "Внутреннее", "Сердце", BType.CASE,
     "Сердце размерами {{ v.size }} см, массой {{ v.mass }} грамм."),
    ("int.vessels", "Внутреннее", "Сосуды", BType.CASE,
     "Сосуды: {{ v }}."),
    ("int.lungs", "Внутреннее", "Лёгкие", BType.CASE,
     "Лёгкие: правое {{ v.right }} г, левое {{ v.left }} г"
     "{% if v.petechiae %}; под легочной плеврой — пятна Тардье{% endif %}."),
    ("int.liver", "Внутреннее", "Печень", BType.CASE,
     "Печень размерами {{ v.size }} см, массой {{ v.mass }} г."),
    ("int.kidneys", "Внутреннее", "Почки", BType.CASE,
     "Почки: правая {{ v.right }}, левая {{ v.left }}."),
    ("int.pancreas", "Внутреннее", "Поджелудочная", BType.CASE,
     "Поджелудочная железа {{ v }}."),
    ("int.stomach", "Внутреннее", "Желудок", BType.CASE,
     "В желудке {{ v }}."),
    # --- ДОПОЛНИТЕЛЬНЫЕ ---
    ("labs.toxicology", "Допы", "Судебно-химическая", BType.EXPERT,
     "{{ v.summary }}"),
    ("labs.histology", "Допы", "Гистология", BType.EXPERT,
     "{{ v.summary }}"),
    # --- ДИАГНОЗ ---
    ("dx.main", "Диагноз", "Основной", BType.EXPERT, "{{ v }}"),
    ("dx.complication", "Диагноз", "Осложнение", BType.EXPERT, "{{ v }}"),
    ("dx.comorbid", "Диагноз", "Сопутствующий", BType.EXPERT, "{{ v }}"),
    ("dx.manipulations", "Диагноз", "Мед. манипуляции", BType.EXPERT, "{{ v }}"),
    # --- ВЫВОДЫ ---
    ("concl.q1", "Выводы", "Причина смерти", BType.EXPERT, "{{ v }}"),
    ("concl.q2", "Выводы", "Давность", BType.EXPERT, "{{ v }}"),
    ("concl.q3", "Выводы", "Токсикология", BType.EXPERT, "{{ v }}"),
]

BLOCKS = [
    Block(bid, sec, title, bt,
          template=_TPL.get(bid, fallback))
    for bid, sec, title, bt, fallback in _SPECS
]
BY_ID = {b.id: b for b in BLOCKS}
