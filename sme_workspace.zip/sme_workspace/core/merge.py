# core/merge.py
from core.blocks import BY_ID, BType, BLOCKS
from enum import Enum

class State(Enum):
    UNSET = "unset"          # нет ни в кейсе, ни в библиотеке
    SET = "set"              # задано экспертом в кейсе
    INHERITED = "inherited"  # взято из библиотеки, требует подтверждения
    CONFLICT = "conflict"    # пока не порождается автоматически; резерв под валидаторы
    DELETED = "deleted"      # помечено НЕ ПРИМЕНИМО
    CONFIRMED = "confirmed"  # унаследованное подтверждено экспертом

def _score_candidate(cand: dict, features: dict) -> int:
    import json
    try:
        tags = json.loads(cand.get("tags_json") or "{}")
    except Exception:
        tags = {}
    s = 0
    for k, v in features.items():
        if v is not None and k in tags and tags[k] == v:
            s += 2
    s += int((cand.get("confidence") or 0) * 3)
    return s

def merge_from_db(case: dict, features: dict, db, blocks=BLOCKS) -> dict:
    """Возвращает {block_id: (state, value, source_desc)}."""
    out = {}
    for b in blocks:
        v = case.get(b.id)
        if v == "__NA__":
            out[b.id] = (State.DELETED, None, None)
            continue
        if v is not None:
            out[b.id] = (State.SET, v, "case")
            continue

        # EXPERT-блоки никогда не наследуются слепо
        cands = db.candidates(b.id) if b.btype != BType.EXPERT else []
        if not cands:
            out[b.id] = (State.UNSET, None, None)
            continue

        best = max(cands, key=lambda c: _score_candidate(c, features))
        import json
        try:
            val = json.loads(best["value_json"])
        except Exception:
            val = best.get("rendered")
        src = f"№{best.get('doc_number')} от {best.get('doc_date')} ({best.get('doc_expert')})"
        out[b.id] = (State.INHERITED, val, src)
    return out

def apply_confirmations(merged: dict, confirmed: set) -> dict:
    for bid in confirmed:
        s, v, src = merged[bid]
        if s == State.INHERITED:
            merged[bid] = (State.CONFIRMED, v, src)
    return merged
