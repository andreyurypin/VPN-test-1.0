# core/validators.py

def validate(merged: dict) -> list[str]:
    """Список противоречий для показа эксперту перед подписью."""
    problems = []

    def val(bid):
        return merged.get(bid, (None, None, None))[1]

    teeth = val("ext.teeth") or ""
    low = teeth.lower()
    if "отсутствуют" in low and "коронк" in low:
        problems.append("Зубы: одновременно «отсутствуют» и «под коронками» — уточните формулировку.")

    spots = val("ext.spots")
    if isinstance(spots, dict):
        if spots.get("reaction") and "не изменяют" in spots["reaction"] and spots.get("pale_time"):
            problems.append("Трупные пятна: «не изменяют окраску», но задано время побледнения.")

    tox = val("labs.toxicology")
    if isinstance(tox, dict) and tox.get("positive") and "ethanol" not in tox:
        problems.append("Токсикология положительная, но результат по спиртам не заполнен — вывод №2 не соберётся.")

    heart = val("int.heart")
    if isinstance(heart, dict) and (heart.get("mass") or 0) > 550:
        problems.append(f"Масса сердца {heart['mass']} г — при такой гипертрофии проверьте основной и сопутствующий диагноз.")

    dx_main = val("dx.main")
    if dx_main and "не обнаружено" in dx_main.lower() and isinstance(tox, dict) and tox.get("positive"):
        problems.append("Диагноз «не обнаружено» противоречит положительной токсикологии.")

    return problems
