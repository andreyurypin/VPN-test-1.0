# core/ingest.py
import re, hashlib
from pathlib import Path
from docx import Document
from core.db import DB
from core.anonymize import anonymize

# Единый список веществ — и для фич, и для извлечения блоков
DRUGS = ("метадон", "морфин", "амфетамин", "мефедрон", "кодеин")
_DRUG_RE = re.compile(r"обнаружен[ы]?\s+(" + "|".join(DRUGS) + r")", re.I)

SECTION_MARKERS = [
    ("НАРУЖНОЕ ИССЛЕДОВАНИЕ", "external"),
    ("ВНУТРЕННЕЕ ИССЛЕДОВАНИЕ", "internal"),
    ("РЕЗУЛЬТАТЫ ДОПОЛНИТЕЛЬНЫХ", "labs"),
    ("СУДЕБНО–МЕДИЦИНСКИЙ ДИАГНОЗ", "diagnosis"),
    ("СУДЕБНО-МЕДИЦИНСКИЙ ДИАГНОЗ", "diagnosis"),
    ("ВЫВОДЫ", "conclusions"),
]

def read_docx_text(path: Path) -> str:
    doc = Document(path)
    return "\n".join(p.text for p in doc.paragraphs)

def read_txt_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")

def split_sections(text: str) -> dict:
    out, current = {}, None
    for line in text.splitlines():
        up = line.strip().upper()
        matched = None
        for marker, sec in SECTION_MARKERS:
            if up.startswith(marker):
                matched = sec
                break
        if matched:
            current = matched
            out.setdefault(current, [])
        elif current:
            out[current].append(line)
    return {k: "\n".join(v) for k, v in out.items()}

def norm(s: str) -> str:
    return re.sub(r"\s+", " ", s).strip()

def extract_metadata(text: str) -> dict:
    """ВАЖНО: запускать ДО anonymize — шапке нужны ФИО и даты."""
    meta = {"number": None, "date": None, "expert": None}
    m = re.search(r"№\s*_?(\d+)_?", text)
    if m:
        meta["number"] = m.group(1)
    m = re.search(r"(\d{1,2}\s+\w+\s+\d{4})\s*г\..*?судебно-медицинскую экспертизу", text, re.S)
    if m:
        meta["date"] = norm(m.group(1))
    m = re.search(r"[Ээ]ксперт[^.\n]*?([А-Я][а-я]+)\s+([А-Я]\.\s?[А-Я]\.)", text)
    if m:
        meta["expert"] = f"{m.group(1)} {m.group(2)}"
    return meta

def extract_features_from_text(text: str) -> dict:
    f = {}
    if "мужского пола" in text.lower(): f["sex"] = "мужского"
    elif "женского пола" in text.lower(): f["sex"] = "женского"
    m = re.search(r"длиной тела\s*(\d+)\s*см", text)
    if m: f["length"] = int(m.group(1))
    m = re.search(r"[Мм]асса трупа\s*(\d+)\s*кг", text)
    if m: f["weight"] = int(m.group(1))
    f["has_injuries"] = bool(re.search(r"определяются\s+\d+\s+ран", text))
    f["has_scars"] = bool(re.search(r"рубец на передней брюшной стенке", text))
    m = _DRUG_RE.search(text)
    f["toxicology_positive"] = bool(m)
    if m: f["drug"] = m.group(1).lower()
    f["vessels_hard"] = bool(re.search(r"режутся с хрустом", text))
    m = re.search(r"[Мм]асса сердца\s*(\d+)", text)
    if m: f["heart_mass"] = int(m.group(1))
    return f

# ---------- блоки ----------
def extract_blocks(section: str, text: str) -> dict:
    """Возвращает {block_id: (value, confidence)}"""
    r = {}

    if section == "external":
        m = re.search(r"Труп доставлен в (.+?)\.", text)
        if m:
            r["ext.clothing"] = (m.group(1).strip(), 0.9)

        m = re.search(r"длиной тела (\d+) см\. Масса трупа (\d+) кг", text)
        if m:
            sex = "мужского" if "мужского пола" in text else (
                  "женского" if "женского пола" in text else None)
            r["ext.body"] = ({"sex": sex,
                              "length": int(m.group(1)),
                              "weight": int(m.group(2))}, 0.95)

        m = re.search(r"трупное окоченение\s+(.+?)\.", text, re.I)
        if m:
            r["ext.rigor"] = (norm(m.group(1)), 0.85)

        m = re.search(r"[Тт]рупные пятна\s+(.+?)\.\s*При надавливании", text, re.S)
        if m:
            color_loc = norm(m.group(1))
            r["ext.spots"] = ({"color": color_loc, "location": "",
                               "reaction": "", "pale_time": None}, 0.6)

        m = re.search(r"Волосы на голове\s+(.+?), длиной до ([\d,]+) см", text)
        if m:
            r["ext.hair"] = ({"color": norm(m.group(1)),
                              "length": float(m.group(2).replace(",", "."))}, 0.8)

        m = re.search(r"Радужные оболочки\s+([\w\s]+?),\s*зрачки[^.]*?по\s*([\d,]+)\s*см", text)
        if m:
            r["ext.eyes"] = ({"iris": norm(m.group(1)),
                              "pupil": float(m.group(2).replace(",", "."))}, 0.85)

        m = re.search(r"Зубы[:\s]+(.+?)\.", text)
        if m:
            r["ext.teeth"] = (norm(m.group(1)), 0.7)

        # Повреждения: грубая эвристика
        if "не обнаружено" not in text.lower() or "определяются" in text:
            injuries = []
            for m in re.finditer(r"Рана №\s*\d+[:\s]+(.+?)(?=\.\s*Рана|\.\s*На |\.\s*Все |\Z)",
                                 text, re.S):
                injuries.append("Рана: " + norm(m.group(1))[:200])
            if injuries:
                r["ext.injuries"] = (injuries, 0.5)

    elif section == "internal":
        m = re.search(r"Сердце\s+.+?размерами\s+([\dх×,]+)\s*см"
                      r".*?[Мм]асса сердца\s*(\d+)", text, re.S)
        if m:
            r["int.heart"] = ({"size": m.group(1), "mass": int(m.group(2))}, 0.85)

        m = re.search(r"Аорта с внутренней поверхности(.+?)\.\s*Атеросклеротический процесс",
                      text, re.S)
        if m:
            r["int.vessels"] = (norm(m.group(1))[:300], 0.6)

    elif section == "labs":
        m = re.search(r"обнаружены:\s*(.+?)\.\s*Не обнаружены", text, re.S | re.I)
        if m:
            body = norm(m.group(1))
            drug = None
            for d in DRUGS:
                if d in body.lower():
                    drug = d; break
            r["labs.toxicology"] = ({
                "summary": "Обнаружены: " + body,
                "positive": True, "drug": drug,
                "blood": _num(r"в крови\s*([\d.,]+)\s*мг/л", text),
                "urine": _num(r"в моче\s*([\d.,]+)\s*мг/л", text),
                "eddp": "EDDP" in body,
                "ethanol": False,
            }, 0.9)
        elif re.search(r"не обнаружены:\s*этиловый", text, re.I):
            r["labs.toxicology"] = ({
                "summary": "Спирты и наркотические вещества не обнаружены.",
                "positive": False, "ethanol": False,
            }, 0.9)

        m = re.search(r"ВЫВОДЫ:\s*(.+?)(?:Врач|\Z)", text, re.S)
        if m and "гистолог" in text.lower():
            r["labs.histology"] = ({
                "summary": norm(m.group(1))[:500],
                "positive": True,
            }, 0.7)

    elif section == "diagnosis":
        m = re.search(r"ОСНОВНОЙ:\s*(.+?)(?:\nОСЛОЖНЕНИЕ|\Z)", text, re.S)
        if m: r["dx.main"] = (norm(m.group(1)), 0.8)
        m = re.search(r"ОСЛОЖНЕНИЕ:\s*(.+?)(?:\nСОПУТСТВУЮЩИЙ|\Z)", text, re.S)
        if m: r["dx.complication"] = (norm(m.group(1)), 0.8)
        m = re.search(r"СОПУТСТВУЮЩИЙ:\s*(.+?)(?:\nМЕДИЦИНСКИЕ|\Z)", text, re.S)
        if m: r["dx.comorbid"] = (norm(m.group(1)), 0.8)

    elif section == "conclusions":
        items = re.split(r"\n\s*\d+\.\s*", "\n" + text)
        items = [norm(x) for x in items if x.strip()]
        for i, item in enumerate(items, start=1):
            r[f"concl.q{i}"] = (item[:600], 0.7)

    return r

def _num(pattern, text):
    m = re.search(pattern, text)
    if not m: return None
    try:
        return float(m.group(1).replace(",", "."))
    except ValueError:
        return None

def ingest_file(path: Path, db: DB) -> dict:
    """Импорт одного файла. Возвращает {doc_id, blocks, duplicate}.

    Обезличивание: metadata извлекается из сырого текста ДО анонимизации,
    в базу и в fingerprint идёт уже вычищенный текст."""
    if path.suffix.lower() == ".docx":
        text = read_docx_text(path)
    elif path.suffix.lower() == ".txt":
        text = read_txt_text(path)
    else:
        return {"error": f"unsupported: {path.suffix}"}

    meta = extract_metadata(text)
    clean = anonymize(text)
    fp = hashlib.sha256(clean.encode("utf-8")).hexdigest()
    if db.has_fingerprint(fp):
        return {"duplicate": True, "path": str(path)}

    doc_id = db.insert_document(
        number=meta.get("number"), date=meta.get("date"),
        expert=meta.get("expert"), raw_text=clean, fingerprint=fp,
        source="archive", status="draft",
    )

    features = extract_features_from_text(clean)
    tags = {k: v for k, v in features.items() if v is not None}

    sections = split_sections(clean)
    extracted = {}
    for sec, body in sections.items():
        for block_id, (value, conf) in extract_blocks(sec, body).items():
            bv_id = db.insert_block_value(
                document_id=doc_id, block_id=block_id, value=value,
                extracted_by="parser_v1", confidence=conf,
                status="needs_review", tags=tags,
            )
            extracted[bv_id] = {"block_id": block_id, "value": value,
                                "confidence": conf, "section": sec,
                                "doc_id": doc_id}

    return {"doc_id": doc_id, "blocks": extracted, "path": str(path),
            "meta": meta, "duplicate": False}

def ingest_folder(folder: Path, db: DB) -> list:
    results = []
    for p in sorted(folder.rglob("*")):
        if p.suffix.lower() in (".docx", ".txt"):
            try:
                results.append(ingest_file(p, db))
            except Exception as e:
                results.append({"error": str(e), "path": str(p)})
    return results
