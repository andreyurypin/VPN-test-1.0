# tests/test_ingest.py
"""Запуск: pytest tests/test_ingest.py  или  python tests/test_ingest.py"""
import sys, tempfile, shutil
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT))

from core.db import DB
from core.ingest import ingest_file, ingest_folder, extract_features_from_text
from core.anonymize import anonymize
try:
    from tests.make_fixtures import make_docx, T400
except ImportError:
    from make_fixtures import make_docx, T400


def test_anonymize_cuts_pii():
    raw = "Экспертиза гр. Иванов Иван Иванович, 15.03.1980 г.р., ул. Ленина, д. 5."
    clean = anonymize(raw)
    assert "Иванов" not in clean and "[ДАННЫЕ УДАЛЕНЫ]" in clean
    assert "15.03.1980" not in clean
    assert "ул." not in clean


def test_ingest_extracts_blocks():
    tmp = Path(tempfile.mkdtemp())
    try:
        db = DB(tmp / "t.db")
        p = tmp / "expert_400.docx"
        make_docx(str(p), T400)
        res = ingest_file(p, db)
        assert not res.get("duplicate")
        assert res["doc_id"] == 1
        assert res["meta"]["expert"] == "Урюпин А.К."
        block_ids = {v["block_id"] for v in res["blocks"].values()}
        assert "ext.body" in block_ids
        assert "labs.toxicology" in block_ids
        assert "dx.main" in block_ids
        assert "concl.q1" in block_ids
        # в raw_text нет персональных данных
        doc = db.get_block_value(1)
        raw = db.list_documents()[0]["raw_text"]
        assert "Иванов" not in raw
        assert "[ДАННЫЕ УДАЛЕНЫ]" in raw
        db.close()
    finally:
        shutil.rmtree(tmp)


def test_ingest_duplicate():
    tmp = Path(tempfile.mkdtemp())
    try:
        db = DB(tmp / "t.db")
        p = tmp / "expert_400.docx"
        make_docx(str(p), T400)
        ingest_file(p, db)
        res2 = ingest_file(p, db)
        assert res2.get("duplicate")
        db.close()
    finally:
        shutil.rmtree(tmp)


if __name__ == "__main__":
    test_anonymize_cuts_pii()
    test_ingest_extracts_blocks()
    test_ingest_duplicate()
    print("test_ingest: OK")
