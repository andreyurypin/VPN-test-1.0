# tests/test_rules.py
"""Запуск: pytest tests/test_rules.py  или  python tests/test_rules.py"""
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

from core.rules import build_diagnosis, build_conclusions
from core.validators import validate
from core.merge import State


def test_diagnosis_metadon_with_missing_concentrations():
    merged = {"labs.toxicology": (State.INHERITED,
                                  {"positive": True, "drug": "метадон",
                                   "blood": None, "urine": None, "ethanol": False},
                                  "src")}
    dx = build_diagnosis(merged, {})
    assert "н/д" in dx["main"]          # нет KeyError
    assert dx["warnings"]               # предупреждение про концентрации


def test_conclusions_unknown_drug():
    merged = {"labs.toxicology": (State.INHERITED,
                                  {"positive": True, "drug": None}, "src")}
    out = build_conclusions(merged, {})
    assert "[УТОЧНИТЬ ВЕЩЕСТВО]" in out[0]


def test_conclusions_numbering_continuous():
    merged = {"labs.toxicology": (State.INHERITED,
                                  {"positive": True, "drug": "метадон",
                                   "ethanol": None}, "src")}
    out = build_conclusions(merged, {})
    assert out[0].startswith("1.")
    assert out[1].startswith("2.")
    assert "не исследовались" in out[1]


def test_unknown_preliminary_blocks():
    dx = build_diagnosis({}, {"meta.preliminary": "ХЗТ"})
    assert dx["blocked"] and "ХЗТ" in dx["blocked"][0]


def test_validate_teeth_contradiction():
    merged = {"ext.teeth": (State.SET, "отсутствуют, но 4-7 под коронками", None)}
    assert any("Зубы" in p for p in validate(merged))


def test_validate_spots_contradiction():
    merged = {"ext.spots": (State.SET, {"reaction": "не изменяют интенсивность окраски",
                                        "pale_time": 18}, None)}
    assert any("пятна" in p for p in validate(merged))


def test_validate_ok_case():
    assert validate({}) == []


if __name__ == "__main__":
    test_diagnosis_metadon_with_missing_concentrations()
    test_conclusions_unknown_drug()
    test_conclusions_numbering_continuous()
    test_unknown_preliminary_blocks()
    test_validate_teeth_contradiction()
    test_validate_spots_contradiction()
    test_validate_ok_case()
    print("test_rules: OK")
