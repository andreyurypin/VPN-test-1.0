# tests/test_merge.py
"""Запуск: pytest tests/test_merge.py  или  python tests/test_merge.py"""
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

from core.merge import merge_from_db, apply_confirmations, State
from core.blocks import BType


class FakeDB:
    def __init__(self, cands):
        self._cands = cands  # block_id -> list[dict]
    def candidates(self, block_id):
        return self._cands.get(block_id, [])


def test_case_overrides_library():
    db = FakeDB({"ext.body": [{"value_json": '{"sex":"мужского","length":172,"weight":95}',
                               "confidence": 0.95, "doc_number": "400",
                               "doc_date": "2025-10-12", "doc_expert": "Урюпин"}]})
    case = {"ext.body": {"sex": "мужского", "length": 177, "weight": 83}}
    m = merge_from_db(case, {}, db)
    assert m["ext.body"][0] == State.SET and m["ext.body"][2] == "case"


def test_inheritance_from_library():
    db = FakeDB({"ext.clothing": [{"value_json": '"трусах красных"', "confidence": 0.9,
                                   "doc_number": "400", "doc_date": "2025-10-12",
                                   "doc_expert": "Урюпин"}]})
    m = merge_from_db({}, {}, db)
    assert m["ext.clothing"][0] == State.INHERITED
    assert m["ext.clothing"][1] == "трусах красных"
    assert "№400" in m["ext.clothing"][2]


def test_na_deletes():
    m = merge_from_db({"ext.teeth": "__NA__"}, {}, FakeDB({}))
    assert m["ext.teeth"][0] == State.DELETED


def test_expert_never_inherits():
    db = FakeDB({"labs.toxicology": [{"value_json": '{"summary":"x"}', "confidence": 1.0,
                                      "doc_number": "400", "doc_date": "2025-10-12",
                                      "doc_expert": "У"}]})
    m = merge_from_db({}, {}, db)
    assert m["labs.toxicology"][0] == State.UNSET


def test_tag_scoring_prefers_matching_candidate():
    cands = [
        {"value_json": '"мягкие"', "confidence": 0.6,
         "tags_json": '{"vessels_hard": false}', "doc_number": "401"},
        {"value_json": '"режутся с хрустом"', "confidence": 0.6,
         "tags_json": '{"vessels_hard": true}', "doc_number": "364"},
    ]
    db = FakeDB({"int.vessels": cands})
    features = {"vessels_hard": True}
    m = merge_from_db({}, features, db)
    assert "364" in m["int.vessels"][2]


def test_confirmations_survive_recalc():
    db = FakeDB({"ext.clothing": [{"value_json": '"трусах красных"', "confidence": 0.9,
                                   "doc_number": "400", "doc_date": "2025-10-12",
                                   "doc_expert": "Урюпин"}]})
    m1 = merge_from_db({}, {}, db)
    confirmed = {"ext.clothing"}
    m1 = apply_confirmations(m1, confirmed)
    assert m1["ext.clothing"][0] == State.CONFIRMED
    # пересчёт заново + повторное применение подтверждений
    m2 = merge_from_db({}, {}, db)
    m2 = apply_confirmations(m2, confirmed)
    assert m2["ext.clothing"][0] == State.CONFIRMED


if __name__ == "__main__":
    test_case_overrides_library()
    test_inheritance_from_library()
    test_na_deletes()
    test_expert_never_inherits()
    test_tag_scoring_prefers_matching_candidate()
    test_confirmations_survive_recalc()
    print("test_merge: OK")
