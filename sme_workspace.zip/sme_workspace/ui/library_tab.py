# ui/library_tab.py
import json
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QTableWidget, QTableWidgetItem,
    QPushButton, QLineEdit, QLabel, QMessageBox,
)
from PySide6.QtCore import Qt
from core.db import DB
from ui.widgets import make_item


class LibraryTab(QWidget):
    """Просмотр approved-блоков, отзыв одобрения, пометка deprecated."""

    def __init__(self, db: DB, parent=None):
        super().__init__(parent)
        self.db = db
        self._build()

    def _build(self):
        layout = QVBoxLayout(self)
        top = QHBoxLayout()
        top.addWidget(QLabel("Фильтр по блоку:"))
        self.filter_edit = QLineEdit()
        self.filter_edit.setPlaceholderText("например, ext.spots")
        self.filter_edit.textChanged.connect(self.refresh)
        top.addWidget(self.filter_edit, 1)
        btn_revoke = QPushButton("Отозвать одобрение")
        btn_revoke.clicked.connect(self.on_revoke)
        btn_deprecate = QPushButton("Пометить deprecated")
        btn_deprecate.clicked.connect(self.on_deprecate)
        btn_refresh = QPushButton("Обновить")
        btn_refresh.clicked.connect(self.refresh)
        top.addWidget(btn_revoke); top.addWidget(btn_deprecate); top.addWidget(btn_refresh)
        layout.addLayout(top)

        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(
            ["Блок", "Документ", "Значение", "Conf", "Подтвердил", "bv_id"])
        self.table.setColumnHidden(5, True)
        self.table.setColumnWidth(0, 160)
        self.table.setColumnWidth(1, 200)
        self.table.setColumnWidth(2, 520)
        self.table.setColumnWidth(3, 60)
        self.table.setColumnWidth(4, 120)
        layout.addWidget(self.table, 1)

    def refresh(self, *args):
        self.table.setRowCount(0)
        block_id = self.filter_edit.text().strip() or None
        for r in self.db.list_approved_blocks(block_id):
            row = self.table.rowCount()
            self.table.insertRow(row)
            val = r["value_json"]
            try:
                val_disp = json.dumps(json.loads(val), ensure_ascii=False)
            except Exception:
                val_disp = str(val)
            doc_label = f"№{r['doc_number'] or '?'} от {r['doc_date'] or '?'}"
            cells = [r["block_id"], doc_label, val_disp[:400],
                     f"{r['confidence']:.2f}" if r["confidence"] is not None else "—",
                     r["confirmed_by"] or "—", str(r["id"])]
            for col, text in enumerate(cells):
                self.table.setItem(row, col, make_item(text, role=r["id"]))

    def _selected(self):
        return {it.data(Qt.UserRole)
                for row in range(self.table.rowCount())
                for col in range(5)
                if (it := self.table.item(row, col)) and it.isSelected()}

    def on_revoke(self):
        ids = self._selected()
        if not ids:
            QMessageBox.information(self, "Нет выбора", "Выделите строки для отзыва.")
            return
        if QMessageBox.question(
                self, "Отзыв одобрения",
                f"Отозвать одобрение у {len(ids)} блоков?") == QMessageBox.Yes:
            for bv_id in ids:
                self.db.set_block_status(bv_id, "rejected")
            self.refresh()

    def on_deprecate(self):
        ids = self._selected()
        if not ids: return
        for bv_id in ids:
            self.db.set_block_status(bv_id, "deprecated")
        self.refresh()
