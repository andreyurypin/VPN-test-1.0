# ui/build_tab.py
import json, hashlib, datetime
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QTableWidget, QTableWidgetItem,
    QPushButton, QTextEdit, QLabel, QSplitter, QMessageBox, QFileDialog,
    QInputDialog,
)
from PySide6.QtCore import Qt
from core.blocks import BY_ID
from core.merge import merge_from_db, apply_confirmations, State
from core.scoring import extract_features
from core.render import render_report, render_block
from core.rules import build_diagnosis, build_conclusions
from core.validators import validate
from core.db import DB
from ui.widgets import COLORS, make_item

NEW_CASE = {
    "ext.clothing": "трусах чёрных хлопчатобумажных",
    "ext.body": {"sex": "мужского", "length": 177, "weight": 83},
    "ext.rigor": "хорошо выражено во всех группах исследованных мышц",
    "ext.spots": {"color": "багрово-синюшные", "location": "передняя поверхность",
                  "reaction": "бледнеют при надавливании", "pale_time": 18},
    "ext.hair": {"color": "седые", "length": 1},
    "ext.eyes": {"iris": "серые", "pupil": 0.5},
    "ext.teeth": "отсутствуют",
    "ext.injuries": [],
    "int.heart": {"size": "11×11×5", "mass": 387},
    "int.vessels": "с бляшками, режутся с хрустом",
    "meta.preliminary": "АБС",
}


class BuildTab(QWidget):
    def __init__(self, db: DB, default_expert: str = "Урюпин А.К.", parent=None):
        super().__init__(parent)
        self.db = db
        self.default_expert = default_expert
        self.case = dict(NEW_CASE)
        self.features = {}
        self.merged = {}
        self.confirmed = set()
        self._build()

    def _build(self):
        layout = QVBoxLayout(self)
        top = QHBoxLayout()
        self.score_label = QLabel("—")
        btn_recalc = QPushButton("Пересчитать по библиотеке")
        btn_recalc.clicked.connect(self.rebuild_merge)
        top.addWidget(QLabel("Кандидаты:"))
        top.addWidget(self.score_label); top.addStretch()
        top.addWidget(btn_recalc)
        layout.addLayout(top)

        split = QSplitter(Qt.Horizontal)
        self.table = QTableWidget(0, 3)
        self.table.setHorizontalHeaderLabels(["Блок", "Состояние", "Источник"])
        self.table.setColumnWidth(0, 220)
        self.table.setColumnWidth(1, 110)
        self.table.setColumnWidth(2, 260)
        self.table.itemSelectionChanged.connect(self.on_select)
        split.addWidget(self.table)

        right = QWidget(); rl = QVBoxLayout(right)
        self.title = QLabel("— выберите блок —")
        rl.addWidget(self.title)
        self.editor = QTextEdit()
        rl.addWidget(self.editor, 1)
        row = QHBoxLayout()
        b_apply = QPushButton("Применить")
        b_apply.clicked.connect(self.on_apply)
        b_confirm = QPushButton("Подтвердить унаследованное")
        b_confirm.clicked.connect(self.on_confirm)
        b_na = QPushButton("НЕ ПРИМЕНИМО")
        b_na.clicked.connect(self.on_na)
        row.addWidget(b_apply); row.addWidget(b_confirm); row.addWidget(b_na)
        rl.addLayout(row)
        split.addWidget(right)
        split.setSizes([600, 800])
        layout.addWidget(split, 1)

        bottom = QHBoxLayout()
        btn_prev = QPushButton("Предпросмотр")
        btn_prev.clicked.connect(self.on_preview)
        btn_dx = QPushButton("Диагноз и выводы")
        btn_dx.clicked.connect(self.on_dx)
        btn_lib = QPushButton("В библиотеку")
        btn_lib.clicked.connect(self.on_save_to_library)
        btn_export = QPushButton("Экспорт DOCX")
        btn_export.clicked.connect(self.on_export)
        bottom.addWidget(btn_prev); bottom.addWidget(btn_dx)
        bottom.addWidget(btn_lib); bottom.addWidget(btn_export)
        layout.addLayout(bottom)

        self.preview = QTextEdit(); self.preview.setReadOnly(True)
        layout.addWidget(self.preview, 1)

    def rebuild_merge(self):
        self.features = extract_features(self.case)
        self.merged = merge_from_db(self.case, self.features, self.db)
        # подтверждения переживают пересчёт
        self.merged = apply_confirmations(self.merged, self.confirmed)
        n_inh = sum(1 for s, _, _ in self.merged.values() if s == State.INHERITED)
        n_unset = sum(1 for s, _, _ in self.merged.values() if s == State.UNSET)
        self.score_label.setText(
            f"унаследовано {n_inh}, требует ввода {n_unset} "
            f"(библиотека: {len(self.db.block_ids_with_approved())} блоков)"
        )
        self._fill_table()

    def _fill_table(self):
        self.table.setRowCount(0)
        for bid, (state, val, src) in self.merged.items():
            b = BY_ID[bid]
            r = self.table.rowCount()
            self.table.insertRow(r)
            cells = [f"{b.section} / {b.title}", state.value, src or ""]
            for c, text in enumerate(cells):
                self.table.setItem(r, c, make_item(text, bg=COLORS[state], role=bid))

    def _current_bid(self):
        items = self.table.selectedItems()
        if not items: return None
        return items[0].data(Qt.UserRole)

    def on_select(self):
        bid = self._current_bid()
        if not bid: return
        b = BY_ID[bid]
        state, val, src = self.merged[bid]
        self.title.setText(f"{b.title}  [{state.value}]  {src or ''}")
        self.editor.setPlainText("" if val is None else
                                 (val if isinstance(val, str)
                                  else json.dumps(val, ensure_ascii=False, indent=2)))

    def on_apply(self):
        bid = self._current_bid()
        if not bid: return
        text = self.editor.toPlainText().strip()
        if not text:
            self.case.pop(bid, None)
        else:
            try:
                self.case[bid] = json.loads(text)
            except Exception:
                self.case[bid] = text
        self.rebuild_merge()

    def on_confirm(self):
        bid = self._current_bid()
        if not bid: return
        if self.merged[bid][0] == State.INHERITED:
            self.confirmed.add(bid)
            self.merged = apply_confirmations(self.merged, self.confirmed)
            self._fill_table()

    def on_na(self):
        bid = self._current_bid()
        if not bid: return
        self.case[bid] = "__NA__"
        self.rebuild_merge()

    def on_preview(self):
        self.preview.setPlainText(render_report(self.merged, self.confirmed))

    def on_dx(self):
        dx = build_diagnosis(self.merged, self.case)
        concl = build_conclusions(self.merged, self.case)
        out = ["=== СУДЕБНО-МЕДИЦИНСКИЙ ДИАГНОЗ ===",
               f"ОСНОВНОЙ: {dx['main'] or '[НЕ СОБРАНО]'}",
               f"ОСЛОЖНЕНИЕ: {dx['complication'] or '-'}",
               f"СОПУТСТВУЮЩИЙ: {dx['comorbid'] or '[НЕ СОБРАНО]'}",
               f"МЕД. МАНИПУЛЯЦИИ: {dx['manipulations'] or '-'}"]
        if dx["warnings"]:
            out.append("\n[ПРЕДУПРЕЖДЕНИЯ]")
            out += dx["warnings"]
        if dx["blocked"]:
            out.append("\n[СТОП-ФАКТОРЫ]")
            out += dx["blocked"]
        out.append("\n=== ВЫВОДЫ ===")
        out += concl
        self.preview.setPlainText("\n".join(str(x) for x in out))

    def _show_problems(self):
        problems = validate(self.merged)
        if problems:
            QMessageBox.warning(self, "Противоречия",
                                "\n".join("• " + p for p in problems))
        return problems

    def on_save_to_library(self):
        """Подписание: текущий черновик -> документ со статусом signed,
        подтверждённые/заданные блоки -> approved. Теперь они доступны
        для наследования через candidates()."""
        self._show_problems()
        text = self.preview.toPlainText().strip()
        if not text:
            QMessageBox.information(self, "Пусто", "Сначала выполните «Предпросмотр».")
            return
        expert, ok = QInputDialog.getText(self, "Подписание", "Эксперт (ФИО):",
                                          text=self.default_expert)
        if not ok or not expert.strip():
            return
        expert = expert.strip()
        doc_id = self.db.insert_document(
            number=None, date=datetime.date.today().isoformat(),
            expert=expert, raw_text=text,
            fingerprint=hashlib.sha256(text.encode("utf-8")).hexdigest(),
            source="live", status="signed",
        )
        n = 0
        for bid, (state, val, src) in self.merged.items():
            if state in (State.SET, State.CONFIRMED) and val is not None:
                bv_id = self.db.insert_block_value(
                    doc_id, bid, val, rendered=render_block(bid, val),
                    extracted_by="expert", confidence=1.0,
                    status="approved", tags=self.features,
                )
                self.db.supersede_block(doc_id, bid, bv_id)
                n += 1
        QMessageBox.information(
            self, "Библиотека",
            f"Документ #{doc_id} подписан ({expert}).\n"
            f"Одобрено блоков: {n}. Теперь они доступны для наследования.")

    def on_export(self):
        text = self.preview.toPlainText().strip()
        if not text:
            self.on_preview()
            text = self.preview.toPlainText().strip()
        if not text:
            QMessageBox.information(self, "Пусто",
                                    "Нет данных для экспорта: пересчитайте сборку.")
            return
        path, _ = QFileDialog.getSaveFileName(self, "Экспорт", "заключение.docx", "*.docx")
        if path:
            from core.export import export_docx
            export_docx(text, path)
            n_unset = sum(1 for s, v, _ in self.merged.values()
                          if s == State.UNSET and v is None)
            warn = f"\n\nВнимание: {n_unset} блоков без данных." if n_unset else ""
            QMessageBox.information(self, "Готово", f"Сохранено: {path}{warn}")
