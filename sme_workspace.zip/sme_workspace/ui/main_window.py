# ui/main_window.py
import json, shutil, datetime, sys
from pathlib import Path

from PySide6.QtWidgets import QApplication, QMainWindow, QTabWidget, QMessageBox
from core.db import DB, ROOT
from ui.archive_tab import ArchiveTab
from ui.build_tab import BuildTab
from ui.library_tab import LibraryTab


def _settings() -> dict:
    p = ROOT / "config" / "settings.json"
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {}


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("СМЭ — рабочее место эксперта")
        self.resize(1500, 850)
        cfg = _settings()
        self.backup_dir = ROOT / cfg.get("backup_dir", "backups")
        self.default_expert = cfg.get("default_expert", "Урюпин А.К.")
        self.highlight_below = cfg.get("highlight_below", 0.7)
        self.db = DB()

        tabs = QTabWidget()
        self.archive_tab = ArchiveTab(self.db, self.default_expert, self.highlight_below)
        self.build_tab = BuildTab(self.db, self.default_expert)
        self.library_tab = LibraryTab(self.db)
        tabs.addTab(self.archive_tab, "Разбор архива")
        tabs.addTab(self.build_tab, "Сборка")
        tabs.addTab(self.library_tab, "Библиотека")

        if not self.db.block_ids_with_approved():
            QMessageBox.information(
                self, "Библиотека пуста",
                "В библиотеке нет одобренных блоков.\n"
                "Откройте вкладку «Разбор архива» и импортируйте папку "
                "с экспертизами (DOCX/TXT)."
            )
        self.setCentralWidget(tabs)

    def closeEvent(self, event):
        """Ежедневный бэкап БД перед закрытием."""
        try:
            self.backup_dir.mkdir(parents=True, exist_ok=True)
            dst = self.backup_dir / f"sme_backup_{datetime.date.today():%Y%m%d}.db"
            if not dst.exists() and self.db.path.exists():
                shutil.copy2(self.db.path, dst)
        except Exception as e:
            QMessageBox.warning(self, "Бэкап", f"Не удалось создать копию: {e}")
        self.db.close()
        super().closeEvent(event)


def main():
    app = QApplication(sys.argv)
    w = MainWindow(); w.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
