# ui/archive_tab.py
import json
from pathlib import Path
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QTableWidget, QTableWidgetItem,
    QPushButton, QTextEdit, QMessageBox, QFileDialog, QLabel, QLineEdit,
)
from PySide6.QtGui import QColor
from PySide6.QtCore import Qt
from core.ingest import ingest_folder, ingest_file
from core.db import DB
from ui.widgets import make_item


class ArchiveTab(QWidget):
    def __init__(self, db: DB, default_expert: str = "Урюпин А.К.",
                 highlight_below: float = 0.7, parent=None):
        super().__init__(parent)
        self.db = db
        self.highlight_below = highlight_below
        self._build(default_expert)

    def _build(self, default_expert):
        layout = QVBoxLayout(self)

        top = QHBoxLayout()
        btn_folder = QPushButton("Импортировать папку…")
        btn_folder.clicked.connect(self.on_import_folder)
        btn_file = QPushButton("Импортировать файл…")
        btn_file.clicked.connect(self.on_import_file)
        self.expert_edit = QLineEdit(default_expert)
        self.expert_edit.setPlaceholderText("Кто подтверждает")
        btn_approve = QPushButton("Одобрить выделенные")
        btn_approve.clicked.connect(self.on_approve)
        btn_approve_hi = QPushButton("Одобрить все с confidence ≥ 0.9")
        btn_approve_hi.clicked.connect(self.on_approve_high)
        btn_reject = QPushButton("Отклонить выделенные")
        btn_reject.clicked.connect(self.on_reject)
        btn_refresh = QPushButton("Обновить")
        btn_refresh.clicked.connect(self.refresh)

        top.addWidget(btn_folder); top.addWidget(btn_file)
        top.addStretch()
        top.addWidget(QLabel("Эксперт:")); top.addWidget(self.expert_edit)
        top.addWidget(btn_approve); top.addWidget(btn_approve_hi)
        top.addWidget(btn_reject); top.addWidget(btn_refresh)
        layout.addLayout(top)

        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(
            ["Документ", "Блок", "Значение", "Conf", "Статус", "bv_id"])
        self.table.setColumnHidden(5, True)
        self.table.setColumnWidth(0, 180)
        self.table.setColumnWidth(1, 180)
        self.table.setColumnWidth(2, 500)
        self.table.setColumnWidth(3, 60)
        self.table.setColumnWidth(4, 120)
        layout.addWidget(self.table, 1)

        self.log = QTextEdit(); self.log.setReadOnly(True)
        self.log.setMaximumHeight(120)
        layout.addWidget(self.log)

    def log_msg(self, s):
        self.log.append(s)

    def on_import_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Папка с экспертизами")
        if not folder: return
        self._run_ingest(Path(folder))

    def on_import_file(self):
        path, _ = QFileDialog.getOpenFileName(self, "Файл экспертизы", "",
                                              "Экспертизы (*.docx *.txt)")
        if not path: return
        self._run_ingest(Path(path))

    def _run_ingest(self, path: Path):
        if path.is_dir():
            results = ingest_folder(path, self.db)
        else:
            results = [ingest_file(path, self.db)]
        ok = sum(1 for r in results if r.get("doc_id"))
        dup = sum(1 for r in results if r.get("duplicate"))
        err = sum(1 for r in results if r.get("error"))
        self.log_msg(f"Импорт: успешно {ok}, дубликатов {dup}, ошибок {err}")
        for r in results:
            if r.get("error"):
                self.log_msg(f"  ОШИБКА {r['path']}: {r['error']}")
        self.refresh()

    def refresh(self):
        self.table.setRowCount(0)
        rows = self.db.conn.execute("""
            SELECT bv.*, d.number, d.date, d.expert
              FROM block_values bv JOIN documents d ON d.id = bv.document_id
             WHERE bv.status IN ('needs_review')
             ORDER BY d.date DESC, bv.id
        """).fetchall()
        for r in rows:
            r = dict(r)
            row = self.table.rowCount()
            self.table.insertRow(row)
            doc_label = f"№{r['number'] or '?'} от {r['date'] or '?'}"
            val = r["value_json"]
            try:
                val_disp = json.dumps(json.loads(val), ensure_ascii=False)
            except Exception:
                val_disp = str(val)
            cells = [doc_label, r["block_id"], val_disp[:300],
                     f"{r['confidence']:.2f}", r["status"], str(r["id"])]
            bg = QColor("#ffd9b3") if (r["confidence"] is not None
                                       and r["confidence"] < self.highlight_below) else None
            # bv_id кладём в UserRole всех ячеек — выделение любой видимой ячейки работает
            for col, text in enumerate(cells):
                self.table.setItem(row, col, make_item(text, bg=bg, role=r["id"]))

    def _selected_bv_ids(self):
        return {it.data(Qt.UserRole)
                for row in range(self.table.rowCount())
                for col in range(5)
                if (it := self.table.item(row, col)) and it.isSelected()}

    def on_approve(self):
        ids = self._selected_bv_ids()
        if not ids:
            QMessageBox.information(self, "Нет выбора",
                                    "Выделите строки (или блоки) для одобрения")
            return
        expert = self.expert_edit.text().strip() or "—"
        for bv_id in ids:
            self.db.approve_block(bv_id, expert)
        self.log_msg(f"Одобрено {len(ids)} блоков ({expert})")
        self.refresh()

    def on_approve_high(self):
        rows = self.db.conn.execute("""
            SELECT id FROM block_values
             WHERE status = 'needs_review' AND confidence >= 0.9
        """).fetchall()
        expert = self.expert_edit.text().strip() or "—"
        for r in rows:
            self.db.approve_block(r["id"], expert)
        self.log_msg(f"Одобрено {len(rows)} блоков с confidence ≥ 0.9")
        self.refresh()

    def on_reject(self):
        ids = self._selected_bv_ids()
        if not ids: return
        expert = self.expert_edit.text().strip() or "—"
        for bv_id in ids:
            self.db.reject_block(bv_id, expert)
        self.log_msg(f"Отклонено {len(ids)} блоков")
        self.refresh()
