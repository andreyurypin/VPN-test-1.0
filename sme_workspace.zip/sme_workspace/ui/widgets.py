# ui/widgets.py
import difflib
from PySide6.QtGui import QColor
from PySide6.QtWidgets import QTableWidgetItem
from PySide6.QtCore import Qt
from core.merge import State

COLORS = {
    State.UNSET:     QColor("#ffffff"),
    State.SET:       QColor("#c8f5c8"),
    State.INHERITED: QColor("#fff3b0"),
    State.CONFLICT:  QColor("#ffb3b3"),
    State.DELETED:   QColor("#d0d0d0"),
    State.CONFIRMED: QColor("#b0e0ff"),
}

def make_item(text: str, bg: QColor = None, role=None):
    it = QTableWidgetItem(text)
    if bg is not None:
        it.setBackground(bg)
    if role is not None:
        it.setData(Qt.UserRole, role)
    return it

def diff_view(base_text: str, new_text: str) -> str:
    """Простой текстовый diff для сравнения с унаследованным вариантом."""
    delta = difflib.unified_diff(
        base_text.splitlines(), new_text.splitlines(),
        fromfile="библиотека", tofile="кейс", lineterm="")
    return "\n".join(delta)
